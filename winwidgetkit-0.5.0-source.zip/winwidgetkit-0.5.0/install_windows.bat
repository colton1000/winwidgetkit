@echo off
setlocal
cd /d "%~dp0"
echo Installing WinWidgetKit from:
echo %CD%
echo.
py -m pip install --upgrade pip
if errorlevel 1 goto error
py -m pip install -e .
if errorlevel 1 goto error
echo.
py -c "import winwidgetkit; print('WinWidgetKit installed successfully. Version:', winwidgetkit.__version__)"
if errorlevel 1 goto error
echo.
echo Starting the widget demo...
py examples\all_widgets.py
pause
exit /b 0
:error
echo.
echo Installation failed. Make sure Python from python.org is installed and the py command works.
pause
exit /b 1
