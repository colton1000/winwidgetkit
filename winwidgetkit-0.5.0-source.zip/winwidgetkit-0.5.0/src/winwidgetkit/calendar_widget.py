import calendar,tkinter as tk
from datetime import date
from .base import DesktopWidget
class CalendarWidget(DesktopWidget):
    def __init__(self,app,**kwargs):
        today=date.today();saved=app.settings_for(kwargs["widget_id"]);self.year=saved.get("year",today.year);self.month=saved.get("month",today.month);kwargs.setdefault("title","Calendar");kwargs.setdefault("width",315);kwargs.setdefault("height",285);super().__init__(app,**kwargs);self.nav=tk.Frame(self.body,bg=self.color);self.nav.pack(fill="x");tk.Button(self.nav,text="<",command=lambda:self.change(-1)).pack(side="left");self.label=tk.Label(self.nav,bg=self.color,fg="white");self.label.pack(side="left",expand=True);tk.Button(self.nav,text=">",command=lambda:self.change(1)).pack(side="right");self.grid=tk.Frame(self.body,bg=self.color);self.grid.pack(fill="both",expand=True);self.draw()
    def change(self,n):m=self.month+n;self.year+=(m-1)//12;self.month=(m-1)%12+1;self.draw();self.app.save_widget(self);self.app.log("calendar_month_changed",widget_id=self.widget_id,year=self.year,month=self.month)
    def draw(self):
        for w in self.grid.winfo_children():w.destroy()
        self.label.config(text=f"{calendar.month_name[self.month]} {self.year}")
        for col,name in enumerate(("Mon","Tue","Wed","Thu","Fri","Sat","Sun")):tk.Label(self.grid,text=name,bg=self.color,fg="#7dd3fc").grid(row=0,column=col,sticky="nsew")
        today=date.today()
        for row,week in enumerate(calendar.Calendar().monthdayscalendar(self.year,self.month),1):
            for col,day in enumerate(week):
                current=day and (self.year,self.month,day)==(today.year,today.month,today.day);tk.Label(self.grid,text=day or "",bg="#fb7185" if current else self.color,fg="white").grid(row=row,column=col,sticky="nsew")
        for col in range(7):self.grid.columnconfigure(col,weight=1)
    def on_color_changed(self,c):self.nav.config(bg=c);self.label.config(bg=c);self.grid.config(bg=c);self.draw()
    def get_settings(self):d=super().get_settings();d.update(year=self.year,month=self.month);return d
