import math,random,time,tkinter as tk
from .base import DesktopWidget
class FocusOrbWidget(DesktopWidget):
    """Animated focus timer. Click the orb for sparkles; use Start for a focus session."""
    def __init__(self,app,*,minutes=25,**kwargs):
        kwargs.setdefault("title","Focus Orb");kwargs.setdefault("width",290);kwargs.setdefault("height",300);saved=app.settings_for(kwargs["widget_id"]);self.duration=int(saved.get("duration",minutes*60));self.remaining=float(saved.get("remaining",self.duration));self.running=False;self.started=0;self.angle=0;self.sparkles=[];self._job=None;super().__init__(app,**kwargs)
        self.canvas=tk.Canvas(self.body,bg=self.color,highlightthickness=0);self.canvas.pack(fill="both",expand=True);self.canvas.bind("<Button-1>",self.sparkle);self.button=tk.Button(self.body,text="Start Focus",command=self.toggle);self.button.place(relx=.5,rely=.91,anchor="center");self._animate()
    def current_remaining(self):return max(0,self.remaining-(time.perf_counter()-self.started if self.running else 0))
    def toggle(self):
        if self.running:self.remaining=self.current_remaining();self.running=False;self.button.config(text="Start Focus");self.app.log("focus_paused",widget_id=self.widget_id,seconds=round(self.remaining))
        else:
            if self.remaining<=0:self.remaining=self.duration
            self.started=time.perf_counter();self.running=True;self.button.config(text="Pause Focus");self.app.log("focus_started",widget_id=self.widget_id,seconds=round(self.remaining))
        self.app.save_widget(self)
    def sparkle(self,event):
        for _ in range(12):self.sparkles.append([event.x,event.y,random.uniform(-2.5,2.5),random.uniform(-3,-.5),random.randint(10,24)])
        self.app.log("focus_orb_sparkled",widget_id=self.widget_id)
    def _animate(self):
        try:
            remaining=self.current_remaining()
            if self.running and remaining<=0:self.running=False;self.remaining=0;self.button.config(text="Restart Focus");self.window.bell();self.app.log("focus_completed",widget_id=self.widget_id)
            self.angle=(self.angle+2)%360;self.canvas.delete("all");w=max(20,self.canvas.winfo_width());h=max(20,self.canvas.winfo_height());cx,cy=w/2,h*.43;r=min(w,h)*.25*(1+.04*math.sin(math.radians(self.angle*2)))
            colors=("#7dd3fc","#a78bfa","#fb7185","#fbbf24")
            for i,color in enumerate(colors[::-1]):rr=r+i*10;self.canvas.create_oval(cx-rr,cy-rr,cx+rr,cy+rr,outline=color,width=3)
            progress=remaining/self.duration if self.duration else 0;self.canvas.create_arc(cx-r-16,cy-r-16,cx+r+16,cy+r+16,start=90,extent=-360*progress,style="arc",outline="white",width=7)
            self.canvas.create_text(cx,cy-8,text=f"{int(remaining//60):02d}:{int(remaining%60):02d}",fill="white",font=("Segoe UI",24,"bold"));self.canvas.create_text(cx,cy+25,text="Click for sparks",fill="#dbeafe",font=("Segoe UI",9))
            alive=[]
            for s in self.sparkles:
                s[0]+=s[2];s[1]+=s[3];s[3]+=.12;s[4]-=1
                if s[4]>0:self.canvas.create_oval(s[0]-2,s[1]-2,s[0]+2,s[1]+2,fill=random.choice(colors),outline="");alive.append(s)
            self.sparkles=alive;self._job=self.window.after(33,self._animate)
        except tk.TclError:self._job=None
    def on_color_changed(self,c):self.canvas.config(bg=c)
    def get_settings(self):d=super().get_settings();d.update(duration=self.duration,remaining=self.current_remaining());return d
    def close(self):
        if self._job:
            try:self.window.after_cancel(self._job)
            except tk.TclError:pass
        super().close()
