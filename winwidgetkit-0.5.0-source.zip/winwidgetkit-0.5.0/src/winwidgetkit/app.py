import json, os, tkinter as tk
from pathlib import Path
from .activity import ActivityLogger
class WidgetApp:
    def __init__(self,config_path=None,default_color=None,app_name="WinWidgetKit App",logging=True,log_directory=None):
        self.root=tk.Tk(); self.root.withdraw(); self.default_color=default_color; self.widgets=[]; self._quitting=False
        default=Path(os.getenv("APPDATA",Path.home()))/"WinWidgetKit"/"widgets.json"
        self.config_path=Path(config_path) if config_path else default; self.config_path.parent.mkdir(parents=True,exist_ok=True)
        try:self.config=json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError,json.JSONDecodeError):self.config={}
        self.logger=ActivityLogger(app_name,log_directory) if logging else None
    def log(self,event,**details):
        if self.logger:
            try:self.logger.record(event,**details)
            except Exception as error:print(f"[WinWidgetKit] Logging error: {error}")
    def settings_for(self,widget_id):return self.config.get(widget_id,{})
    def save_widget(self,widget):
        try:
            self.config[widget.widget_id]=widget.get_settings(); temp=self.config_path.with_suffix(".tmp")
            temp.write_text(json.dumps(self.config,indent=2),encoding="utf-8"); temp.replace(self.config_path)
        except (OSError,tk.TclError) as error:self.log("settings_save_failed",widget_id=getattr(widget,"widget_id","unknown"),error=repr(error))
    def register(self,widget):self.widgets.append(widget);self.log("widget_created",widget_id=widget.widget_id,widget_type=type(widget).__name__)
    def unregister(self,widget):
        if widget in self.widgets:self.widgets.remove(widget)
        self.log("widget_closed",widget_id=widget.widget_id)
        if not self.widgets and not self._quitting:self._quitting=True;self.root.after_idle(self.root.quit)
    def run(self):
        self.log("event_loop_started",library="tkinter")
        try:self.root.mainloop()
        finally:
            self.log("event_loop_stopped")
            if self.logger:
                try:self.logger.write()
                except Exception as error:print(f"[WinWidgetKit] Could not write log: {error}")
            try:self.root.destroy()
            except tk.TclError:pass
