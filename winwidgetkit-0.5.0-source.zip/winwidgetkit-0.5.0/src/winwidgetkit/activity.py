from datetime import datetime
from pathlib import Path
import platform, sys
class ActivityLogger:
    def __init__(self, app_name="WinWidgetKit App", log_directory=None, echo=True):
        self.app_name=app_name; self.echo=echo; self.started=datetime.now(); self.entries=[]; self.closed=False
        self.log_directory=Path(log_directory) if log_directory else Path.home()/"Downloads"
        self.record("application_started",python=sys.version.split()[0],system=platform.platform())
        self.record("library_used",library="tkinter",purpose="desktop graphical widgets")
    def record(self,event,**details):
        line=f"[{datetime.now().astimezone().isoformat(timespec='seconds')}] {event}"
        if details: line += " | " + "; ".join(f"{k}={v}" for k,v in details.items())
        self.entries.append(line)
        if self.echo: print("[WinWidgetKit]",line,flush=True)
    def write(self):
        if self.closed:return getattr(self,"last_path",None)
        self.record("application_closed",elapsed_seconds=round((datetime.now()-self.started).total_seconds(),2)); self.closed=True
        try:self.log_directory.mkdir(parents=True,exist_ok=True)
        except OSError:self.log_directory=Path.cwd()
        safe="".join(c if c.isalnum() or c in "-_" else "_" for c in self.app_name).strip("_") or "WinWidgetKit"
        self.last_path=self.log_directory/f"{safe}_{datetime.now():%Y-%m-%d_%H-%M-%S}.log.txt"
        head=["WinWidgetKit Activity Report",f"Application: {self.app_name}",f"Script: {Path(sys.argv[0]).resolve()}","","This lists actions reported by WinWidgetKit. It is not an antivirus scan or proof that arbitrary code is safe.",""]
        self.last_path.write_text("\n".join(head+self.entries)+"\n",encoding="utf-8")
        if self.echo:print(f"[WinWidgetKit] Log saved to: {self.last_path}",flush=True)
        return self.last_path
