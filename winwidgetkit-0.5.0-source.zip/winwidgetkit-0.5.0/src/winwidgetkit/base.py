import tkinter as tk
from tkinter import colorchooser
from .theme import get_default_color
class DesktopWidget:
    def __init__(self,app,*,widget_id,x=50,y=50,width=220,height=160,min_width=140,min_height=90,color=None,title="Widget",always_on_top=False,resizable=True):
        self.app,self.widget_id=app,widget_id;self.min_width,self.min_height=min_width,min_height;s=app.settings_for(widget_id)
        self.color=s.get("color",color or app.default_color or get_default_color());self.always_on_top=s.get("always_on_top",always_on_top)
        x,y,w,h=s.get("x",x),s.get("y",y),s.get("width",width),s.get("height",height)
        self.window=tk.Toplevel(app.root);self.window.overrideredirect(True);self.window.geometry(f"{w}x{h}+{x}+{y}");self.window.configure(bg=self.color);self.window.attributes("-topmost",self.always_on_top)
        shade=self._shade(self.color);self.header=tk.Frame(self.window,bg=shade,height=28,cursor="fleur");self.header.pack(fill="x");self.header.pack_propagate(False)
        self.title_label=tk.Label(self.header,text=title,bg=shade,fg="white",font=("Segoe UI",9,"bold"));self.title_label.pack(side="left",padx=8)
        self.close_button=tk.Label(self.header,text="x",bg=shade,fg="white",cursor="hand2");self.close_button.pack(side="right",padx=8);self.close_button.bind("<Button-1>",lambda e:self.close())
        self.body=tk.Frame(self.window,bg=self.color);self.body.pack(fill="both",expand=True)
        self.grip=tk.Label(self.window,text="◢",bg=self.color,fg="white",cursor="size_nw_se")
        if resizable:self.grip.place(relx=1,rely=1,anchor="se")
        self.grip.bind("<ButtonPress-1>",self._resize_start);self.grip.bind("<B1-Motion>",self._resize_move);self.grip.bind("<ButtonRelease-1>",self._resize_end)
        self.menu=tk.Menu(self.window,tearoff=False);self.menu.add_command(label="Change color",command=self.choose_color);self.menu.add_command(label="Always on top",command=self.toggle_topmost);self.menu.add_separator();self.menu.add_command(label="Close widget",command=self.close)
        self._hold_job=None;self._held=False;self.bind_controls(self.window,self.header,self.title_label,self.body);app.register(self)
    @staticmethod
    def _shade(color,factor=.72):
        try:v=color.lstrip("#");r,g,b=(int(v[i:i+2],16) for i in (0,2,4));return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"
        except Exception:return "#1a1a1a"
    def bind_controls(self,*controls):
        for c in controls:
            c.bind("<ButtonPress-1>",self._drag_start,add="+");c.bind("<B1-Motion>",self._drag_move,add="+");c.bind("<ButtonRelease-1>",self._drag_end,add="+");c.bind("<ButtonPress-3>",self._right_start,add="+");c.bind("<ButtonRelease-3>",self._right_end,add="+")
    def _drag_start(self,e):self._drag_offset=(e.x_root-self.window.winfo_x(),e.y_root-self.window.winfo_y())
    def _drag_move(self,e):self.window.geometry(f"+{max(0,e.x_root-self._drag_offset[0])}+{max(0,e.y_root-self._drag_offset[1])}")
    def _drag_end(self,e):self.app.save_widget(self);self.app.log("widget_moved",widget_id=self.widget_id,x=self.window.winfo_x(),y=self.window.winfo_y())
    def _resize_start(self,e):self._resize_origin=(e.x_root,e.y_root,self.window.winfo_width(),self.window.winfo_height())
    def _resize_move(self,e):
        x,y,w,h=self._resize_origin;nw=max(self.min_width,w+e.x_root-x);nh=max(self.min_height,h+e.y_root-y);self.window.geometry(f"{nw}x{nh}");self.grip.lift()
    def _resize_end(self,e):self.app.save_widget(self);self.app.log("widget_resized",widget_id=self.widget_id,width=self.window.winfo_width(),height=self.window.winfo_height())
    def _right_start(self,e):self._held=False;self._hold_job=self.window.after(2000,self._long_right)
    def _long_right(self):self._hold_job=None;self._held=True;self.choose_color()
    def _right_end(self,e):
        if self._hold_job:self.window.after_cancel(self._hold_job);self._hold_job=None
        if not self._held:self.menu.tk_popup(e.x_root,e.y_root)
    def choose_color(self):
        value=colorchooser.askcolor(self.color,parent=self.window)[1]
        if value:self.set_color(value)
    def set_color(self,color):
        self.color=color;shade=self._shade(color);self.window.config(bg=color);self.body.config(bg=color);self.header.config(bg=shade);self.title_label.config(bg=shade);self.close_button.config(bg=shade);self.grip.config(bg=color);self.on_color_changed(color);self.app.save_widget(self);self.app.log("widget_color_changed",widget_id=self.widget_id,color=color)
    def on_color_changed(self,color):pass
    def toggle_topmost(self):self.always_on_top=not self.always_on_top;self.window.attributes("-topmost",self.always_on_top);self.app.save_widget(self)
    def get_settings(self):return {"x":self.window.winfo_x(),"y":self.window.winfo_y(),"width":self.window.winfo_width(),"height":self.window.winfo_height(),"color":self.color,"always_on_top":self.always_on_top}
    def close(self):self.app.save_widget(self);self.window.destroy();self.app.unregister(self)
