from pathlib import Path
import os,tkinter as tk
from tkinter import filedialog,messagebox
from .base import DesktopWidget
class ShortcutWidget(DesktopWidget):
    def __init__(self,app,*,target=None,label=None,**kwargs):
        kwargs.setdefault("title","Shortcut");kwargs.setdefault("height",145);super().__init__(app,**kwargs);self.target=app.settings_for(self.widget_id).get("target",target or "");self.custom_label=label;self.icon=tk.Label(self.body,text="↗",font=("Segoe UI",30,"bold"),bg=self.color,fg="#fbbf24");self.icon.pack();self.name=tk.Label(self.body,bg=self.color,fg="white");self.name.pack();self._refresh();self.menu.insert_command(0,label="Select target",command=self.select);self.icon.bind("<Double-1>",lambda e:self.open());self.name.bind("<Double-1>",lambda e:self.open())
    def _refresh(self):self.name.config(text=self.custom_label or (Path(self.target).name if self.target else "Choose a file"))
    def select(self):
        value=filedialog.askopenfilename(parent=self.window)
        if value:self.target=value;self.custom_label=None;self._refresh();self.app.save_widget(self);self.app.log("shortcut_target_selected",widget_id=self.widget_id,target=value)
    def open(self):
        if not self.target:return self.select()
        try:self.app.log("shortcut_opened",widget_id=self.widget_id,target=self.target);os.startfile(self.target)
        except OSError as error:messagebox.showerror("Cannot open",str(error),parent=self.window)
    def on_color_changed(self,c):self.icon.config(bg=c);self.name.config(bg=c)
    def get_settings(self):d=super().get_settings();d["target"]=self.target;return d
