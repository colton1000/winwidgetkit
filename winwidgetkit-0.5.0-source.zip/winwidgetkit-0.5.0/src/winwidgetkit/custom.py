import importlib.util
from pathlib import Path
from .base import DesktopWidget
class CustomWidget(DesktopWidget):
    def __init__(self,app,*,build,color_handler=None,**kwargs):self._handler=color_handler;super().__init__(app,**kwargs);build(self);app.log("custom_widget_builder_ran",widget_id=self.widget_id)
    def on_color_changed(self,c):
        if self._handler:self._handler(self,c)
class ScriptWidget(CustomWidget):
    def __init__(self,app,*,script_path,**kwargs):
        path=Path(script_path).resolve();app.log("external_widget_script_loading",path=path);spec=importlib.util.spec_from_file_location(f"winwidget_{path.stem}",path)
        if not spec or not spec.loader:raise ImportError(f"Cannot load {path}")
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        if not callable(getattr(module,"build",None)):raise ValueError("Script must define build(widget)")
        kwargs.setdefault("color",getattr(module,"DEFAULT_COLOR",None));super().__init__(app,build=module.build,color_handler=getattr(module,"on_color",None),**kwargs);app.log("external_widget_script_loaded",path=path)
