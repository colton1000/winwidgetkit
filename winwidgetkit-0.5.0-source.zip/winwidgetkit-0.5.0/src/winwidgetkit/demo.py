from . import WidgetApp,AnalogClockWidget,StopwatchWidget,CalendarWidget,ShortcutWidget,FocusOrbWidget
def main():
    app=WidgetApp(app_name="WinWidgetKit 0.5 Demo",default_color="#263653")
    AnalogClockWidget(app,widget_id="clock",x=30,y=30,show_numbers=True)
    StopwatchWidget(app,widget_id="stopwatch",x=290,y=30)
    CalendarWidget(app,widget_id="calendar",x=600,y=30)
    ShortcutWidget(app,widget_id="shortcut",x=30,y=350,label="Choose a file")
    FocusOrbWidget(app,widget_id="focus-orb",x=300,y=350,minutes=25)
    app.run()
if __name__=="__main__":main()
