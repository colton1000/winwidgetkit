from .app import WidgetApp
from .base import DesktopWidget
from .clock import AnalogClockWidget
from .stopwatch import StopwatchWidget
from .calendar_widget import CalendarWidget
from .shortcut import ShortcutWidget
from .focus_orb import FocusOrbWidget
from .custom import CustomWidget,ScriptWidget
from .group import CombinedWidget
from .theme import set_default_color,get_default_color
from .activity import ActivityLogger
__version__="0.5.0"
__all__=["WidgetApp","DesktopWidget","AnalogClockWidget","StopwatchWidget","CalendarWidget","ShortcutWidget","FocusOrbWidget","CustomWidget","ScriptWidget","CombinedWidget","set_default_color","get_default_color","ActivityLogger"]
