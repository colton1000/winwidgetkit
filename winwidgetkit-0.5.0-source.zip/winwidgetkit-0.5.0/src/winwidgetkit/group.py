import tkinter as tk
from .base import DesktopWidget
class CombinedWidget(DesktopWidget):
    def __init__(self,app,*,panels=None,columns=2,**kwargs):
        kwargs.setdefault("title","Combined Widget");kwargs.setdefault("width",480);kwargs.setdefault("height",330);self.frames=[];super().__init__(app,**kwargs);self.content=tk.Frame(self.body,bg=self.color);self.content.pack(fill="both",expand=True,padx=6,pady=6)
        for i,(title,builder) in enumerate(panels or []):frame=tk.LabelFrame(self.content,text=title,bg=self.color,fg="white");frame.grid(row=i//columns,column=i%columns,sticky="nsew",padx=4,pady=4);self.frames.append(frame);builder(frame,self)
        for col in range(columns):self.content.columnconfigure(col,weight=1)
    def on_color_changed(self,c):self.content.config(bg=c);[f.config(bg=c) for f in self.frames]
