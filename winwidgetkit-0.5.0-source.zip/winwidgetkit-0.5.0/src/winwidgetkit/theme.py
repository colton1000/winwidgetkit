DEFAULT_COLOR = "#24283b"
def set_default_color(color):
    global DEFAULT_COLOR
    DEFAULT_COLOR = color
def get_default_color():
    return DEFAULT_COLOR
