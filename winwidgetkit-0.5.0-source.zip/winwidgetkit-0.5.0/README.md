# WinWidgetKit 0.5.0

## Easiest Windows installation

1. Extract this ZIP completely.
2. Double-click `install_windows.bat`.
3. The installer installs the package, verifies `import winwidgetkit`, and opens the demo.
4. Later, double-click `run_demo.bat`.

Do not paste the Python program into the `>>>` interactive prompt.

## Included features

- Resizable and movable widgets with saved positions and sizes
- Analog clock with numbers and persistent daily alarms
- Stopwatch with start, pause, reset, laps and persistence
- Calendar with month navigation and current-day highlighting
- File shortcut widget
- Combined widgets, custom widgets and trusted external script widgets
- Two-second right-click color picker and normal right-click menu
- Package, app and widget default colors
- Console activity messages and a closing report in Downloads
- New Focus Orb with a focus countdown, animated rings and click sparkles

## Manual installation

Open PowerShell in this folder, not inside Python's `>>>` prompt:

```powershell
py -m pip install -e .
py -c "import winwidgetkit; print(winwidgetkit.__version__)"
py examples\all_widgets.py
```

The activity report covers actions WinWidgetKit observes. It is not antivirus software and cannot prove arbitrary third-party scripts are safe.
