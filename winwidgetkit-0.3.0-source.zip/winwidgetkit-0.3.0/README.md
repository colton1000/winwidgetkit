# WinWidgetKit 0.3.0

Movable, colorful, composable and scriptable Windows desktop widgets using Python and Tkinter.

## Install

```powershell
cd winwidgetkit-0.2.0
py -m pip install -e .
winwidgets-demo
```

## New in 0.2.0

- `CombinedWidget` puts multiple custom panels inside one movable widget.
- `CalendarWidget` includes month navigation and highlights today.
- `AnalogClockWidget(show_numbers=True)` displays 1 through 12.
- Hold right-click for two seconds to open the color picker. A normal right-click opens the menu.
- `set_default_color()` controls the package-wide default from your script.
- A script loaded by `ScriptWidget` can define `DEFAULT_COLOR = "#623a77"`.

## Default colors from Python

```python
from winwidgetkit import WidgetApp, CalendarWidget, set_default_color
set_default_color("#173b55")
app = WidgetApp()
CalendarWidget(app, widget_id="calendar")
app.run()
```

You can alternatively use `WidgetApp(default_color="#173b55")`. An explicit widget `color=` wins over the app/package default. A previously saved color wins over all defaults.

## Combining panels

```python
import tkinter as tk
from winwidgetkit import WidgetApp, CombinedWidget

app = WidgetApp()
def notes(frame, widget):
    tk.Text(frame).pack(fill="both", expand=True)
def counter(frame, widget):
    value = tk.IntVar(value=0)
    tk.Label(frame, textvariable=value, bg=widget.color, fg="white").pack()
    tk.Button(frame, text="+1", command=lambda: value.set(value.get()+1)).pack()

CombinedWidget(app, widget_id="combo", panels=[("Notes", notes), ("Counter", counter)])
app.run()
```

## Notes

Only load trusted Python widget scripts. They run with your user account permissions. Settings are saved in `%APPDATA%\WinWidgetKit\widgets.json`.

# Version 0.3.0 additions

- Resize any widget by dragging the bottom-right triangle. Size is saved automatically.
- Set `resizable=False` to lock a widget's size.
- Analog clocks support multiple persistent daily alarms.
- Right-click a clock and choose **Add alarm** or **View or remove alarms**.
- Alarm times use 24-hour `HH:MM` format and produce a Windows bell plus a popup.
- The shortcut widget remains included and can open a selected file by double-clicking.

```python
from winwidgetkit import WidgetApp, AnalogClockWidget, ShortcutWidget

app = WidgetApp(default_color="#20324c")
AnalogClockWidget(app, widget_id="alarm-clock", show_numbers=True,
                  alarms=["07:30", "18:45"], width=280, height=310)
ShortcutWidget(app, widget_id="project-shortcut", x=340, y=40,
               label="Choose a file")
app.run()
```
