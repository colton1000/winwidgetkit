import tkinter as tk
from .base import DesktopWidget
class CombinedWidget(DesktopWidget):
    """One movable widget containing multiple titled panels built with callbacks."""
    def __init__(self,app,*,panels=None,columns=2,**kwargs):
        kwargs.setdefault('title','Combined Widget'); kwargs.setdefault('width',480); kwargs.setdefault('height',330)
        self.panels=panels or []; self.columns=max(1,columns); self.panel_frames=[]
        super().__init__(app,**kwargs); self.content=tk.Frame(self.body,bg=self.color); self.content.pack(fill='both',expand=True,padx=6,pady=6); self._build()
    def _build(self):
        for index,panel in enumerate(self.panels):
            title,builder=panel; frame=tk.LabelFrame(self.content,text=title,bg=self.color,fg='white',font=('Segoe UI',9,'bold'),bd=1)
            frame.grid(row=index//self.columns,column=index%self.columns,sticky='nsew',padx=4,pady=4); self.panel_frames.append(frame); builder(frame,self)
        rows=(len(self.panels)+self.columns-1)//self.columns
        for c in range(self.columns): self.content.columnconfigure(c,weight=1)
        for r in range(rows): self.content.rowconfigure(r,weight=1)
    def on_color_changed(self,color):
        self.content.configure(bg=color)
        for frame in self.panel_frames: frame.configure(bg=color)
