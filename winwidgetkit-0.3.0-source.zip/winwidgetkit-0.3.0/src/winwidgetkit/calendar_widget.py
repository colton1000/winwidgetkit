import calendar, tkinter as tk
from datetime import date
from .base import DesktopWidget
class CalendarWidget(DesktopWidget):
    def __init__(self,app,*,year=None,month=None,**kwargs):
        today=date.today(); saved=app.settings_for(kwargs['widget_id']); self.year=saved.get('year',year or today.year); self.month=saved.get('month',month or today.month)
        kwargs.setdefault('title','Calendar'); kwargs.setdefault('width',315); kwargs.setdefault('height',285)
        super().__init__(app,**kwargs)
        self.nav=tk.Frame(self.body,bg=self.color); self.nav.pack(fill='x',pady=4)
        self.prev=tk.Button(self.nav,text='‹',width=3,command=lambda:self.change_month(-1)); self.prev.pack(side='left',padx=6)
        self.month_label=tk.Label(self.nav,bg=self.color,fg='white',font=('Segoe UI',11,'bold')); self.month_label.pack(side='left',expand=True)
        self.next=tk.Button(self.nav,text='›',width=3,command=lambda:self.change_month(1)); self.next.pack(side='right',padx=6)
        self.grid=tk.Frame(self.body,bg=self.color); self.grid.pack(fill='both',expand=True,padx=7,pady=4); self.draw()
    def change_month(self,amount):
        m=self.month+amount; self.year+=(m-1)//12; self.month=(m-1)%12+1; self.draw(); self.app.save_widget(self)
    def draw(self):
        for w in self.grid.winfo_children(): w.destroy()
        self.month_label.config(text=f'{calendar.month_name[self.month]} {self.year}')
        for col,name in enumerate(('Mon','Tue','Wed','Thu','Fri','Sat','Sun')): tk.Label(self.grid,text=name,bg=self.color,fg='#7dd3fc',font=('Segoe UI',8,'bold')).grid(row=0,column=col,sticky='nsew')
        today=date.today()
        for row,week in enumerate(calendar.Calendar().monthdayscalendar(self.year,self.month),1):
            for col,day in enumerate(week):
                text=str(day) if day else ''; is_today=day and (self.year,self.month,day)==(today.year,today.month,today.day)
                tk.Label(self.grid,text=text,bg='#fb7185' if is_today else self.color,fg='white',font=('Segoe UI',9,'bold' if is_today else 'normal')).grid(row=row,column=col,sticky='nsew',padx=1,pady=1)
        for i in range(7): self.grid.columnconfigure(i,weight=1)
    def on_color_changed(self,color):
        self.nav.configure(bg=color); self.month_label.configure(bg=color); self.grid.configure(bg=color); self.draw()
    def get_settings(self): d=super().get_settings(); d.update(year=self.year,month=self.month); return d
