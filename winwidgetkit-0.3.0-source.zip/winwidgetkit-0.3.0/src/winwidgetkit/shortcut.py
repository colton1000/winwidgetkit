from pathlib import Path
import os, tkinter as tk
from tkinter import filedialog, messagebox
from .base import DesktopWidget
class ShortcutWidget(DesktopWidget):
    def __init__(self,app,*,target=None,label=None,**kwargs):
        kwargs.setdefault('title','Shortcut'); kwargs.setdefault('width',230); kwargs.setdefault('height',145); super().__init__(app,**kwargs)
        self.target=app.settings_for(self.widget_id).get('target',str(target) if target else ''); self.label_text=label
        self.icon=tk.Label(self.body,text='↗',font=('Segoe UI',30,'bold'),bg=self.color,fg='#fbbf24',cursor='hand2'); self.icon.pack(pady=(12,0))
        self.name=tk.Label(self.body,font=('Segoe UI',10,'bold'),bg=self.color,fg='white',cursor='hand2',wraplength=205); self.name.pack(padx=8)
        for c in (self.icon,self.name): c.bind('<Double-Button-1>',lambda e:self.open_target()); self.bind_widget_controls(c)
        self.menu.insert_command(0,label='Select shortcut target',command=self.select_target); self._refresh()
    def _refresh(self): self.name.config(text=self.label_text or (Path(self.target).name if self.target else 'Choose a file'))
    def select_target(self):
        value=filedialog.askopenfilename(parent=self.window,title='Choose a shortcut file')
        if value: self.target=value; self.label_text=None; self._refresh(); self.app.save_widget(self)
    def open_target(self):
        if not self.target: return self.select_target()
        try: os.startfile(self.target)
        except OSError as e: messagebox.showerror('Could not open',str(e),parent=self.window)
    def on_color_changed(self,color): self.icon.config(bg=color); self.name.config(bg=color)
    def get_settings(self): d=super().get_settings(); d['target']=self.target; return d
