DEFAULT_COLOR = "#24283b"

def set_default_color(color: str) -> None:
    """Set the default background color used by widgets created afterward."""
    global DEFAULT_COLOR
    DEFAULT_COLOR = color

def get_default_color() -> str:
    return DEFAULT_COLOR
