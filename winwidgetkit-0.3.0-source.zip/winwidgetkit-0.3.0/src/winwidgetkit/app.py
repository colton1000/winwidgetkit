from __future__ import annotations
import json, os, tkinter as tk
from pathlib import Path

class WidgetApp:
    def __init__(self, config_path=None, default_color=None):
        self.root=tk.Tk(); self.root.withdraw()
        default=Path(os.getenv("APPDATA", Path.home()))/"WinWidgetKit"/"widgets.json"
        self.config_path=Path(config_path) if config_path else default
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        self.config=self._load(); self.widgets=[]; self.default_color=default_color
    def _load(self):
        try: return json.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError): return {}
    def settings_for(self, widget_id): return self.config.get(widget_id,{})
    def save_widget(self, widget):
        self.config[widget.widget_id]=widget.get_settings()
        temp=self.config_path.with_suffix('.tmp')
        temp.write_text(json.dumps(self.config,indent=2),encoding='utf-8'); temp.replace(self.config_path)
    def register(self,w): self.widgets.append(w)
    def unregister(self,w):
        if w in self.widgets: self.widgets.remove(w)
        if not self.widgets: self.root.after_idle(self.root.quit)
    def run(self): self.root.mainloop()
