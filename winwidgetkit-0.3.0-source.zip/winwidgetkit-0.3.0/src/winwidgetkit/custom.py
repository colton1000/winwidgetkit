import importlib.util
from pathlib import Path
from .base import DesktopWidget
class CustomWidget(DesktopWidget):
    def __init__(self,app,*,build,color_handler=None,**kwargs): self._color_handler=color_handler; super().__init__(app,**kwargs); build(self)
    def on_color_changed(self,color):
        if self._color_handler: self._color_handler(self,color)
class ScriptWidget(CustomWidget):
    def __init__(self,app,*,script_path,**kwargs):
        path=Path(script_path).resolve(); spec=importlib.util.spec_from_file_location(f'winwidget_script_{path.stem}',path)
        if not spec or not spec.loader: raise ImportError(f'Cannot load {path}')
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        if not callable(getattr(module,'build',None)): raise ValueError(f'{path} must define build(widget)')
        kwargs.setdefault('color',getattr(module,'DEFAULT_COLOR',None))
        super().__init__(app,build=module.build,color_handler=getattr(module,'on_color',None),**kwargs)
