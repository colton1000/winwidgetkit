import math, tkinter as tk
from datetime import datetime
from tkinter import simpledialog, messagebox
from .base import DesktopWidget

class AnalogClockWidget(DesktopWidget):
    def __init__(self,app,*,show_numbers=False,alarms=None,**kwargs):
        kwargs.setdefault("title","Analog Clock"); kwargs.setdefault("width",230); kwargs.setdefault("height",260)
        saved=app.settings_for(kwargs["widget_id"])
        self.show_numbers=saved.get("show_numbers",show_numbers)
        self.alarms=saved.get("alarms",alarms or [])
        self._fired=set()
        super().__init__(app,**kwargs)
        self.canvas=tk.Canvas(self.body,bg=self.color,highlightthickness=0); self.canvas.pack(fill="both",expand=True)
        self.menu.insert_checkbutton(0,label="Show clock numbers",command=self.toggle_numbers)
        self.menu.insert_command(1,label="Add alarm",command=self.add_alarm)
        self.menu.insert_command(2,label="View or remove alarms",command=self.manage_alarms)
        self._tick()
    def toggle_numbers(self): self.show_numbers=not self.show_numbers; self.app.save_widget(self); self._draw(datetime.now())
    def add_alarm(self):
        value=simpledialog.askstring("Add alarm","Enter a daily alarm in HH:MM format, such as 07:30 or 18:45:",parent=self.window)
        if value is None: return
        try:
            parsed=datetime.strptime(value.strip(),"%H:%M"); normalized=parsed.strftime("%H:%M")
        except ValueError:
            messagebox.showerror("Invalid time","Use 24-hour HH:MM format.",parent=self.window); return
        if normalized not in self.alarms: self.alarms.append(normalized); self.alarms.sort(); self.app.save_widget(self)
    def manage_alarms(self):
        if not self.alarms: messagebox.showinfo("Alarms","No alarms are set.",parent=self.window); return
        value=simpledialog.askstring("Alarms","Daily alarms:\n"+"\n".join(self.alarms)+"\n\nType an exact time to remove it, or leave blank to keep all:",parent=self.window)
        if value and value.strip() in self.alarms: self.alarms.remove(value.strip()); self.app.save_widget(self)
    def _check_alarms(self,now):
        minute_key=now.strftime("%Y-%m-%d %H:%M"); alarm=now.strftime("%H:%M")
        if alarm in self.alarms and minute_key not in self._fired:
            self._fired.add(minute_key); self.window.bell(); self.window.attributes("-topmost",True)
            messagebox.showinfo("Alarm",f"Alarm: {alarm}",parent=self.window)
            self.window.attributes("-topmost",self.always_on_top)
        if len(self._fired)>20: self._fired={minute_key} if minute_key in self._fired else set()
    def _tick(self):
        if self.window.winfo_exists():
            now=datetime.now(); self._draw(now); self._check_alarms(now); self.window.after(250,self._tick)
    def _draw(self,now):
        c=self.canvas; c.delete("all"); w,h=max(c.winfo_width(),20),max(c.winfo_height(),20); cx,cy=w/2,h/2; r=min(w,h)*.42
        c.create_oval(cx-r,cy-r,cx+r,cy+r,fill=self.color,outline="white",width=3)
        for i in range(12):
            a=math.radians(i*30-90); inner=r*(.80 if self.show_numbers else (.82 if i%3 else .75))
            c.create_line(cx+inner*math.cos(a),cy+inner*math.sin(a),cx+r*.93*math.cos(a),cy+r*.93*math.sin(a),fill="white",width=3 if i%3==0 else 1)
            if self.show_numbers:
                na=math.radians(i*30-60)
                c.create_text(cx+r*.67*math.cos(na),cy+r*.67*math.sin(na),text=str(i+1),fill="white",font=("Segoe UI",max(8,int(r/10)),"bold"))
        self._hand(((now.hour%12)+now.minute/60)*30,r*.47,max(3,int(r/16)),"white")
        self._hand(now.minute*6+now.second*.1,r*.69,max(2,int(r/22)),"#7dd3fc")
        self._hand(now.second*6,r*.79,2,"#fb7185")
        c.create_oval(cx-5,cy-5,cx+5,cy+5,fill="white",outline="")
        if self.alarms: c.create_text(cx,cy+r*.88,text="Alarm: "+", ".join(self.alarms[:2]),fill="#fbbf24",font=("Segoe UI",8,"bold"))
    def _hand(self,d,l,w,color):
        a=math.radians(d-90); cx,cy=self.canvas.winfo_width()/2,self.canvas.winfo_height()/2
        self.canvas.create_line(cx,cy,cx+l*math.cos(a),cy+l*math.sin(a),fill=color,width=w,capstyle="round")
    def on_color_changed(self,color): self.canvas.configure(bg=color)
    def get_settings(self):
        d=super().get_settings(); d["show_numbers"]=self.show_numbers; d["alarms"]=self.alarms; return d
