import tkinter as tk
from datetime import datetime
from . import WidgetApp, AnalogClockWidget, CalendarWidget, ShortcutWidget, CombinedWidget

def main():
    app=WidgetApp(default_color='#27304a')
    AnalogClockWidget(app,widget_id='clock',x=30,y=30,show_numbers=True)
    CalendarWidget(app,widget_id='calendar',x=290,y=30,color='#17463b')
    ShortcutWidget(app,widget_id='shortcut',x=640,y=30,label='Choose a file',color='#5b294f')
    def clock_panel(frame,widget):
        label=tk.Label(frame,bg=widget.color,fg='white',font=('Segoe UI',20,'bold')); label.pack(expand=True)
        def tick(): label.config(text=datetime.now().strftime('%I:%M:%S %p')); label.after(250,tick)
        tick()
    def note_panel(frame,widget):
        tk.Label(frame,text='Two widgets combined into one movable window.',bg=widget.color,fg='white',wraplength=190).pack(expand=True,padx=10,pady=10)
    CombinedWidget(app,widget_id='combined',x=80,y=350,panels=[('Clock',clock_panel),('Note',note_panel)])
    app.run()
if __name__=='__main__': main()
