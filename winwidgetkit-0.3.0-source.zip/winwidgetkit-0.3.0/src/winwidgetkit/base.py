from __future__ import annotations
import tkinter as tk
from tkinter import colorchooser
from .theme import get_default_color

class DesktopWidget:
    """Borderless movable widget with persistence, long-press color, and resizing."""
    def __init__(self, app, *, widget_id, x=50, y=50, width=220, height=160,
                 min_width=140, min_height=90, color=None, title="Widget",
                 always_on_top=False, resizable=True):
        self.app, self.widget_id = app, widget_id
        self.min_width, self.min_height, self.resizable = min_width, min_height, resizable
        saved = app.settings_for(widget_id)
        color = color or app.default_color or get_default_color()
        self.color = saved.get("color", color)
        self.always_on_top = saved.get("always_on_top", always_on_top)
        x, y = saved.get("x", x), saved.get("y", y)
        width, height = saved.get("width", width), saved.get("height", height)
        self.window = tk.Toplevel(app.root)
        self.window.overrideredirect(True)
        self.window.geometry(f"{max(width,min_width)}x{max(height,min_height)}+{x}+{y}")
        self.window.configure(bg=self.color)
        self.window.attributes("-topmost", self.always_on_top)
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        shade = self._shade(self.color)
        self.header = tk.Frame(self.window, bg=shade, height=28, cursor="fleur")
        self.header.pack(fill="x"); self.header.pack_propagate(False)
        self.title_label = tk.Label(self.header, text=title, bg=shade, fg="white", font=("Segoe UI",9,"bold"))
        self.title_label.pack(side="left", padx=8)
        self.close_button = tk.Label(self.header, text="x", bg=shade, fg="white", cursor="hand2", font=("Segoe UI",11,"bold"))
        self.close_button.pack(side="right", padx=8); self.close_button.bind("<Button-1>", lambda e:self.close())
        self.body = tk.Frame(self.window, bg=self.color); self.body.pack(fill="both", expand=True)
        self.resize_grip = tk.Label(self.window, text="◢", bg=self.color, fg="white", cursor="size_nw_se", font=("Segoe UI",10))
        if self.resizable: self.resize_grip.place(relx=1,rely=1,anchor="se")
        self.resize_grip.bind("<ButtonPress-1>", self._resize_start)
        self.resize_grip.bind("<B1-Motion>", self._resize_move)
        self.resize_grip.bind("<ButtonRelease-1>", self._resize_end)
        self._drag_offset=(0,0); self._resize_origin=(0,0,0,0)
        self._right_hold_job=None; self._right_hold_triggered=False
        self.menu=tk.Menu(self.window,tearoff=False)
        self.menu.add_command(label="Change color",command=self.choose_color)
        self.menu.add_command(label="Always on top",command=self.toggle_topmost)
        self.menu.add_separator(); self.menu.add_command(label="Close widget",command=self.close)
        self.bind_widget_controls(self.window,self.header,self.title_label,self.body)
        app.register(self)
    def bind_widget_controls(self,*controls):
        for item in controls:
            item.bind("<ButtonPress-1>",self._drag_start,add="+")
            item.bind("<B1-Motion>",self._drag_move,add="+")
            item.bind("<ButtonRelease-1>",self._drag_end,add="+")
            item.bind("<ButtonPress-3>",self._right_start,add="+")
            item.bind("<ButtonRelease-3>",self._right_release,add="+")
    @staticmethod
    def _shade(c,factor=.72):
        try:
            v=c.lstrip("#"); r,g,b=(int(v[i:i+2],16) for i in (0,2,4))
            return f"#{int(r*factor):02x}{int(g*factor):02x}{int(b*factor):02x}"
        except Exception: return "#1a1a1a"
    def _drag_start(self,e): self._drag_offset=(e.x_root-self.window.winfo_x(),e.y_root-self.window.winfo_y())
    def _drag_move(self,e):
        x=e.x_root-self._drag_offset[0]; y=e.y_root-self._drag_offset[1]
        mx=max(0,self.window.winfo_screenwidth()-self.window.winfo_width())
        my=max(0,self.window.winfo_screenheight()-self.window.winfo_height())
        self.window.geometry(f"+{max(0,min(x,mx))}+{max(0,min(y,my))}")
    def _drag_end(self,e): self.app.save_widget(self)
    def _resize_start(self,e):
        self._resize_origin=(e.x_root,e.y_root,self.window.winfo_width(),self.window.winfo_height())
    def _resize_move(self,e):
        sx,sy,sw,sh=self._resize_origin
        max_w=self.window.winfo_screenwidth()-self.window.winfo_x()
        max_h=self.window.winfo_screenheight()-self.window.winfo_y()
        w=max(self.min_width,min(sw+e.x_root-sx,max_w)); h=max(self.min_height,min(sh+e.y_root-sy,max_h))
        self.window.geometry(f"{w}x{h}"); self.on_resize(w,h); self.resize_grip.lift()
    def _resize_end(self,e): self.app.save_widget(self)
    def on_resize(self,width,height): pass
    def _right_start(self,e):
        self._right_hold_triggered=False
        if self._right_hold_job: self.window.after_cancel(self._right_hold_job)
        self._right_hold_job=self.window.after(2000,self._held_color)
    def _held_color(self): self._right_hold_job=None; self._right_hold_triggered=True; self.choose_color()
    def _right_release(self,e):
        if self._right_hold_job: self.window.after_cancel(self._right_hold_job); self._right_hold_job=None
        if not self._right_hold_triggered: self.menu.tk_popup(e.x_root,e.y_root)
    def choose_color(self):
        selected=colorchooser.askcolor(self.color,parent=self.window)[1]
        if selected: self.set_color(selected)
    def set_color(self,color):
        self.color=color; shade=self._shade(color)
        self.window.configure(bg=color); self.body.configure(bg=color); self.header.configure(bg=shade)
        self.title_label.configure(bg=shade); self.close_button.configure(bg=shade); self.resize_grip.configure(bg=color)
        self.on_color_changed(color); self.app.save_widget(self)
    def on_color_changed(self,color): pass
    def toggle_topmost(self):
        self.always_on_top=not self.always_on_top; self.window.attributes("-topmost",self.always_on_top); self.app.save_widget(self)
    def get_settings(self):
        self.window.update_idletasks()
        return {"x":self.window.winfo_x(),"y":self.window.winfo_y(),"width":self.window.winfo_width(),"height":self.window.winfo_height(),"color":self.color,"always_on_top":self.always_on_top}
    def close(self): self.app.save_widget(self); self.window.destroy(); self.app.unregister(self)
