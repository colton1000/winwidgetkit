from .app import WidgetApp
from .base import DesktopWidget
from .clock import AnalogClockWidget
from .calendar_widget import CalendarWidget
from .shortcut import ShortcutWidget
from .custom import CustomWidget, ScriptWidget
from .group import CombinedWidget
from .theme import set_default_color, get_default_color
__version__='0.3.0'
__all__=['WidgetApp','DesktopWidget','AnalogClockWidget','CalendarWidget','ShortcutWidget','CustomWidget','ScriptWidget','CombinedWidget','set_default_color','get_default_color']
