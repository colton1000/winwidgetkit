import tkinter as tk
DEFAULT_COLOR = '#623a77'
def build(widget):
    tk.Label(widget.body,text='This script supplies its default color!',bg=widget.color,fg='white',wraplength=180).pack(expand=True,padx=15,pady=15)
