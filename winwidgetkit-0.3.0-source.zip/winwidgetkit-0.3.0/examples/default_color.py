from winwidgetkit import WidgetApp, AnalogClockWidget, CalendarWidget, set_default_color
set_default_color('#12304a')
app=WidgetApp()
AnalogClockWidget(app,widget_id='clock',x=40,y=40,show_numbers=True)
CalendarWidget(app,widget_id='calendar',x=300,y=40)
app.run()
