from winwidgetkit import WidgetApp, AnalogClockWidget, CalendarWidget, ShortcutWidget

app = WidgetApp(default_color="#263653")
AnalogClockWidget(app, widget_id="alarm-clock", x=40, y=40,
                  show_numbers=True, alarms=["08:00"], width=280, height=310)
CalendarWidget(app, widget_id="calendar", x=350, y=40, width=350, height=320)
ShortcutWidget(app, widget_id="shortcut", x=740, y=40,
               label="Double-click to choose a file")
app.run()
