import tkinter as tk
from winwidgetkit import WidgetApp, CombinedWidget
app=WidgetApp()
def counter(frame,widget):
    value=tk.IntVar(value=0)
    tk.Label(frame,textvariable=value,bg=widget.color,fg='white',font=('Segoe UI',24,'bold')).pack(expand=True)
    tk.Button(frame,text='+1',command=lambda:value.set(value.get()+1)).pack(pady=5)
def notes(frame,widget):
    tk.Text(frame,width=20,height=6).pack(fill='both',expand=True,padx=5,pady=5)
CombinedWidget(app,widget_id='tools',panels=[('Counter',counter),('Notes',notes)],color='#304060')
app.run()
